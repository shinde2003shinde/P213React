
import { useState } from "react";

function Salary(){
    var[number, setName]=useState(33000);

    var change=()=>{
        setName(68000);
    }
    return(
        <div>
            <h1>My Salary Is{number}</h1>
            <button onClick={change}>change</button>
        </div>
    )
}
export default Salary;