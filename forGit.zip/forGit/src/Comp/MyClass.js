import { Component } from "react";

class MyClass extends Component{
    x=30;
    render(){
        return(
            <div>
                <h1>Hello from MyClass Component {this.x} </h1>
          </div>
        )
    }
}
export default MyClass;