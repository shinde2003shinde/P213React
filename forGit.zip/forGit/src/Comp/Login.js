import { useState } from "react";
import { useNavigate } from "react-router-dom";

function Login() {
    var [u, setU] = useState("");
    var [p, setP] = useState("");
    var navigate = useNavigate();


    var first = (e) => {
        setU(e.target.value);

    }
    var second = (e) => {
        setP(e.target.value);

    }
    var Submit = () => {
        if (u === "mayuri" && p === "mayu@1234") {
            navigate("/home");
        } else {
            alert("Invalid Username or Password");
        }
    }
    return (
        <div>
            <h1>Welcome to the Login Page</h1>
            <input type="text" onChange={first} /><br />
            <input type="text" onChange={second} />
            <button onClick={Submit}>Submit</button>
        </div>
    );
}

export default Login;