
import { useRef, useState} from "react";
import "./Navebar.css";
function Home() {
    var inp= useRef();
    var [n,setN]= useState("");
    var fun =()=>{
        setN(inp.current.value);
    }

    return (
        <div className="h">
            <h1>Hello from Home {n} </h1>
            Enter your name <input  type="text" ref={inp}/>
            <button onClick={fun}>Submit</button>
        </div>
    );
}

export default Home;


