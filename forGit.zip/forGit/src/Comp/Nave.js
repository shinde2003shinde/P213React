import { Link } from 'react-router-dom';
import './Navebar.css';

function Navebar() {
    return (
        <div className="n">
            <div className="lo">
                <span className="logo">Welcome to the First Website</span>
            </div>
            <div className='in'>
                <input type="text" placeholder="Search..." className='inp' />
            </div>
            <Link to="/home" className="l">Home</Link>
            <Link to="/about" className="l">About</Link>
            <Link to="/login" className="l">Login</Link>
            <Link to="/signup" className="l">SignUp</Link>
        </div>
    );
}

export default Navebar;
