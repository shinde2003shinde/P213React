import "./Navebar.css";
import { useState } from "react";

function SignUp(){
    
    function pure(a,b){
        var c= a+b;
        return c;

    }
    var r=2;
    function impure(x,y){
        var z= x+y;
        return z*r;
    }
    return(
        <div className="s">
            <h1>Hello from SignUp</h1>
            <h1>{pure(300,200)}</h1>
            <h1>{impure(100,50)}</h1>
        </div>
    )

}
export default SignUp;