import { BrowserRouter, Route, Routes } from 'react-router-dom';
import './App.css';

import Home from './Comp/Home';
import Login from './Comp/Login';
import SignUp from './Comp/SignUp';
import About from './Comp/About';
import Navebar from './Comp/Nave';
import MyClass from './Comp/MyClass';
function App(){
  return(
    <div>
      <MyClass/>
    </div>
  )
}
export default App;