import {useState} from "react";
import "./Conceptss.css";
function Concepts(){
    
    var [obj, setobj] = useState({backgroundColor:"red",height:"200px"});
    var change = ()=>{
        setobj({backgroundColor:"green",height:"100px"});
    }

    return(
        <div>
        <h1 style={obj}>Hello From My concepts</h1>
        <button onClick={change}>Change</button>
        <h2 className="abc">Hello From h2</h2>
        </div>
    )
}
export default Concepts;
// selfclosing tag
// import export
// dbl curly braces for objects
// single braces for javascript
// all attributes write in Camel-case
// hooks concept - useState = used to change the state of variable.