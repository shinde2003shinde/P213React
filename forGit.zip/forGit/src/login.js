import { useState } from "react";


function Login(){
    var [u,setup]= useState("");
    var [p,setup]= useState("");
    var first=(e)=>{
        setup(e.target.value);
    }
    var second=(e)=>{
        SteP (e.target.value);
    }
    return(
        <div className="lo">
            <h1>Hello from Login</h1>
            <input type="text" onChange={first}/>
            <input type="text" onChange={second}/>
            <h1>{u}</h1>
            <h2>{p}</h2>
        </div>
    )
}