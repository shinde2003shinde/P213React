import './App.css';
import SignIn from './01SignIn';
import Conceptss from './Conceptss.js';
import Salary from './numberup.js';



function App() {
  var name="sakshi";
  var num= 1234;
  var arr=[12,13,34,45];
  function fun(){
    var n="mayuri";
    return n;
  }
  var oArr=[{id:1,name: "anuja",city:"pune"},
    {id:2,name:"priyanka",city:"mumbai"},
  {id:3,name:"rajshree",city:"nagar"},];

  return (
    <div><h1> {num} Hello from {fun()} first {arr} app {name}</h1>
    <input type="text"/>

    {oArr.map((s)=>{
      return(
        <div>
        <h1>{s.id}</h1>
        <h1>{s.name}</h1>
        <h1>{s.city}</h1>
   
        </div>
      )
    })};

          <Conceptss/>
         <SignIn/>
         <Salary/>
    </div>
    
    
  );
  
}

export default App;
